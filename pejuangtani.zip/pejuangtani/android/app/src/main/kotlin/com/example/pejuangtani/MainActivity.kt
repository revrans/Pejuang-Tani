package com.example.pejuangtani

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
